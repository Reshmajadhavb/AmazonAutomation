package stepdefinitions;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AddToCartMethods {

	public WebDriver driver;
	String singleHatPriceWith$;

	@Given("Launch the Amazon URL")
	public void launch_the_amazon_url() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}

	@When("Enter productname in the search bar as {string}")
	public void searchProduct(String productname) {
		driver.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("hats for men");
	}

	@When("Click on search button")
	public void clickSearchButton() {
		driver.findElement(By.id("nav-search-submit-button")).click();
	}

	@When("Click on first hat in the product list")
	public void getFirstProduct() {
		driver.findElement(By.xpath(
				"//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//img[1]"))
				.click();

	}

	@When("Select hat quantity as two from dropdown")
	public void selectProductQntyOne() {
		driver.findElement(By.xpath("//span[@class='a-dropdown-label']")).click();
		driver.findElement(By.xpath("//a[@id='quantity_1']")).click();
	}

	@When("Click on Add to cart button")
	public void addToCartButton() {
		driver.findElement(By.id("add-to-cart-button")).click();
	}

	@Then("Success message is displayed")
	public void productAddedMessage() {
		String successMessage = driver
				.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base sw-atc-text a-text-bold']"))
				.getText();
		System.out.println(successMessage);
	}

	@When("Click on Cart button")
	public void goToCartButton() {
		driver.findElement(By.id("nav-cart-text-container")).click();
	}

	@Then("Correct product quantity is displayed")
	public void productQuanityAsTwo() {
		String[] productQnty = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).getText()
				.split(":");
		Assert.assertEquals(productQnty[1], "2");
		System.out.println("Assert successful, hat quantity updated as :" + productQnty[1]);
	}

	@Then("Correct total price is displayed")
	public void totalPriceForTwo() throws InterruptedException {
		Thread.sleep(2000);
		singleHatPriceWith$ = driver.findElement(By.xpath(
				"//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold']"))
				.getText();
		String singleHatPriceWithout$ = singleHatPriceWith$.replaceAll("[$]", "");
		Double singleHatPrice = Double.valueOf(singleHatPriceWithout$);
		System.out.println("Price for single hat is :" + singleHatPrice);

		// assert total price for 2 hats

		String totalPriceWith$ = driver.findElement(By.xpath(
				"//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']"))
				.getText();
		String totalHatPriceWithout$ = totalPriceWith$.replaceAll("[$]", "");
		Double totalPriceForTwo = Double.valueOf(totalHatPriceWithout$);
		Assert.assertEquals(totalPriceForTwo, singleHatPrice * 2);
		System.out.println("Assert success, price for two hats correctly updated as :" + totalPriceForTwo);

	}

	@When("Change the hat quanitity as one from the dropdown")
	public void selectProductQntyTwo() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("quantity_1")).click();
	}

	@Then("Product quantity is updated as one")
	public void productQuanityAsOne() {
		String[] productQntyOne = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).getText()
				.split(":");
		Assert.assertEquals(productQntyOne[1], "1");
		System.out.println("Assert successful, hat quantity updated :" + productQntyOne[1]);
	}

	@And("Total price is updated correctly for one hat")
	public void totalPriceForOne() throws InterruptedException {
		Thread.sleep(5000);
		String totalPriceUpdated = driver.findElement(By.xpath(
				"//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']"))
				.getText();
		Assert.assertEquals(totalPriceUpdated, singleHatPriceWith$);
		System.out.println("Assert successful, total price for one hat is" + totalPriceUpdated);

	}

	@After()
	public void closeBrowser() {
		driver.quit();
	}

}
