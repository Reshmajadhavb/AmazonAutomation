package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import stepdefinitions.AddToCart_Stepdef;

public class ProductPageElements {

	WebDriver driver;
	AddToCart_Stepdef methods;

	public ProductPageElements(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	WebElement pName;

	@FindBy(id = "nav-search-submit-button")
	WebElement searchBtn;
	@FindBy(xpath = "//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//img[1]")
	WebElement selectProduct;

	@FindBy(xpath = "//span[@class='a-dropdown-label']")
	WebElement dropdown;
	@FindBy(xpath = "//a[@id='quantity_1']")
	WebElement selectQnty;

	@FindBy(id = "add-to-cart-button")
	WebElement addToCartButton;

	@FindBy(xpath = "//span[@class='a-size-medium-plus a-color-base sw-atc-text a-text-bold']")
	WebElement addToCartMessage;

	public void searchProduct_pe(String productname) {
		if (pName.isDisplayed()) {
			pName.sendKeys("hats for men");
		} else {
			driver.get("https://www.amazon.com/");
		}
	}

	public void clickSearchButton_pe() {
		searchBtn.click();
	}

	public void getFirstProduct_pe() {

		selectProduct.click();
	}

	public void selectProductQnty_pe() {

		if (dropdown.isDisplayed()) {
			dropdown.click();
			selectQnty.click();
		} else {
			driver.get("https://www.amazon.com/");
		}
	}

	public void addToCartButton_pe() {
		addToCartButton.click();
	}

	public void productAddedMessage_pe() {
		String successMessage = addToCartMessage.getText();
		System.out.println(successMessage);
	}

}
