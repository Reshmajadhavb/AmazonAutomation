package pagefactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class CartPageElements {
	WebDriver driver;

	public CartPageElements(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(id = "nav-cart-text-container")
	WebElement clickCart;

	@FindBy(xpath = "//span[@class='a-button-text a-declarative']")
	WebElement productQnty;

	@FindBy(xpath = "//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold']")
	WebElement singleHatPrice_ele;
	String singleHatPriceWith$;

	@FindBy(xpath = "//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']")
	WebElement totalPriceWith_ele;

	@FindBy(xpath = "//span[@class='a-button-text a-declarative']")
	WebElement cart_drpdwn;
	@FindBy(id = "quantity_1")
	WebElement cart_drpdwnQnty;

	@FindBy(xpath = "//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']")
	WebElement totalPriceUpdated_ele;

	public void goToCartButton_pe() {
		clickCart.click();
	}

	public void productQuanityAsTwo_pe() {
		String[] productQntyArr = productQnty.getText().split(":");
		Assert.assertEquals(productQntyArr[1], "2");
		System.out.println("Assert successful, hat quantity updated as :" + productQntyArr[1]);
	}

	public void totalPriceForTwo_pe() throws InterruptedException {

		singleHatPriceWith$ = singleHatPrice_ele.getText();
		String singleHatPriceWithout$ = singleHatPriceWith$.replaceAll("[$]", "");
		Double singleHatPrice = Double.valueOf(singleHatPriceWithout$);
		System.out.println("Price for single hat is :" + singleHatPrice);

		// assert total price for 2 hats

		String totalPriceWith$ = totalPriceWith_ele.getText();
		String totalHatPriceWithout$ = totalPriceWith$.replaceAll("[$]", "");
		Double totalPriceForTwo = Double.valueOf(totalHatPriceWithout$);
		Assert.assertEquals(totalPriceForTwo, singleHatPrice * 2);
		System.out.println("Assert success, price for two hats correctly updated as :" + totalPriceForTwo);

	}

	public void selectProductQntyOne_pe() throws InterruptedException {
		cart_drpdwn.click();
		cart_drpdwnQnty.click();
	}

	public void productQuanityAsOne_pe() {
		String[] productQntyOne = productQnty.getText().split(":");
		Assert.assertEquals(productQntyOne[1], "1");
		System.out.println("Assert successful, hat quantity updated :" + productQntyOne[1]);
	}

	public void totalPriceForOne_pe() throws InterruptedException {
		String totalPriceUpdated = totalPriceUpdated_ele.getText();
		Assert.assertEquals(totalPriceUpdated, singleHatPriceWith$);
		System.out.println("Assert successful, total price for one hat is" + totalPriceUpdated);

	}

}
