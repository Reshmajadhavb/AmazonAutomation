package pageobjects;


import java.util.NoSuchElementException;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ProductPageElements {

	WebDriver driver;
	WebDriverWait wait;
	 


	public ProductPageElements(WebDriver driver, WebDriverWait wait) {
		this.driver = driver;
		this.wait = wait;
		PageFactory.initElements(driver, this);
		

	}

	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	WebElement search_bar;

	@FindBy(id = "nav-search-submit-button")
	WebElement searchBtn;
	@FindBy(xpath = "//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//img[1]")
	WebElement selectProduct;

	@FindBy(xpath = "//span[@class='a-dropdown-label']")
	WebElement dropdown1;
	@FindBy(xpath = "//a[@id='quantity_1']")
	WebElement selectQnty1;

	@FindBy(xpath = "//span[@class='a-dropdown-prompt'][normalize-space()='Select']")
	WebElement select_size;

	@FindBy(xpath = "//a[@id='native_dropdown_selected_size_name_1']")
	WebElement size_small;

	@FindBy(xpath = "//a[@title='See All Buying Options']")
	WebElement buying_options;

	@FindBy(xpath = "//span[@id='aod-offer-qty-button-1']//input[@type='submit']")
	WebElement dropdown2;
	@FindBy(xpath = "//span[@id='aod-offer-qty-option-1-2']")
	WebElement selectQnty2;

	@FindBy(xpath = "//span[@id='a-autoid-2-offer-1']//input[@name='submit.addToCart']")
	WebElement addToCartButton1;
	@FindBy(xpath = "//i[@aria-label='aod-close']")
	WebElement close_window;

	@FindBy(id = "add-to-cart-button")
	WebElement addToCartButton2;

	@FindBy(xpath = "//span[@class='a-size-medium-plus a-color-base sw-atc-text a-text-bold']")
	WebElement addToCartMessage;

	public void searchProduct_pe(String productname) {
		if (search_bar.isDisplayed()) {
			try {
				search_bar.sendKeys("hats for men");
			} catch (NoSuchElementException e) {
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOf(search_bar));
				search_bar.sendKeys("hats for men");
			}
		} else {
			System.out.println("execute the test again");
		}
	}

	public void clickSearchButton_pe() {
		searchBtn.click();
	}

	public void getFirstProduct_pe() {

		selectProduct.click();
	}

	public void selectProductQnty_pe() throws InterruptedException {
		 //case1
		if(dropdown1!=null)
		{
	    if (dropdown1.isDisplayed()==true) {
	try{
		  dropdown1.click(); 
		  selectQnty1.click(); 
	}catch(NoSuchElementException e){
	System.out.println("quantinty dropdown option not visible");
	}
	    }
		}
		//case2 
		 else if(select_size.isDisplayed()==true) { 
	try{
		select_size.click();
		size_small.click(); 
		buying_options.click(); 
		dropdown2.click(); 
		selectQnty2.click(); 
		addToCartButton1.click();
		close_window.click();
	 }catch(NoSuchElementException e){
	System.out.println("select size option not visible");
	}
		 }
		 //case3 
		 else if(buying_options.isDisplayed()){
	try{
		buying_options.click(); 
		dropdown2.click(); 
		selectQnty2.click();
		addToCartButton1.click();
	    close_window.click();
	}catch (NoSuchElementException e){
	System.out.println("see buying options not visible");
	}
		 }

		//case4
	    else if(addToCartButton1.isEnabled()){
	try{
	    
	    addToCartButton1.click();
		System.out.println("only one product quantinty is available");
	 }catch(NoSuchElementException e){
	System.out.println("add to cart not yet visible");
	}
	    }
	    else{
		System.out.println("exceptional case not caught");
	    }
	}
	
	public void addToCartButton_pe() {
		addToCartButton2.click();
	}

	public void productAddedMessage_pe() {
		String successMessage = addToCartMessage.getText();
		System.out.println(successMessage);
	}

}
