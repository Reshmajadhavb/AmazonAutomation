package stepdefinitions;



import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageobjects.CartPageElements;
import pageobjects.ProductPageElements;
import runner.Runner;

public class AddToCart_Stepdef  {

	WebDriver driver;
	ProductPageElements page;
	CartPageElements cart;
	WebDriverWait wait;
	
	  @Before public void setupDriver() { WebDriverManager.chromedriver().setup();
	  driver = new ChromeDriver(); driver.manage().window().maximize();
	 
	  }

	@Given("Launch the Amazon URL")
	public void launch_the_amazon_url() throws InterruptedException {

		driver.get("https://www.amazon.com/");
		
	}

	@When("Enter productname in the search bar as {string}")
	public void searchProduct(String productname) {
		page = new ProductPageElements(driver, wait);
		page.searchProduct_pe(productname);
	}

	@When("Click on search button")
	public void clickSearchButton() {
		page.clickSearchButton_pe();
	}

	@When("Click on first hat in the product list")
	public void getFirstProduct() {
		page.getFirstProduct_pe();
	}

	@When("Select hat quantity as two from dropdown")
	public void selectProductQntyOne() throws InterruptedException {
		page.selectProductQnty_pe();
	}

	@When("Click on Add to cart button")
	public void addToCartButton() {
		page.addToCartButton_pe();
	}

	@Then("Success message is displayed")
	public void productAddedMessage() {
		page.productAddedMessage_pe();
	}

	@When("Click on Cart button")
	public void goToCartButton() {
		cart = new CartPageElements(driver);
		cart.goToCartButton_pe();
	}

	@Then("Correct product quantity is displayed")
	public void productQuanityAsTwo() {
		cart.productQuanityAsTwo_pe();
	}

	@Then("Correct total price is displayed")
	public void totalPriceForTwo() throws InterruptedException {

		cart.totalPriceForTwo_pe();
	}

	@When("Change the hat quanitity as one from the dropdown")
	public void selectProductQntyTwo() throws InterruptedException {
		cart.selectProductQntyOne_pe();
	}

	@Then("Product quantity is updated as one")
	public void productQuanityAsOne() {
		cart.productQuanityAsOne_pe();
	}

	@And("Total price is updated correctly for one hat")
	public void totalPriceForOne() throws InterruptedException {
		cart.totalPriceForOne_pe();
	}
	
	  @After()
	  public void closeBrowser()
	  {
		  driver.quit();
		  }
	 
}
