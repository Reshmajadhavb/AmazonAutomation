package stepdefinitions;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddToCartMethods {

	WebDriver driver;
	Pattern p;

	String singleHatPriceWith$ = driver.findElement(By.xpath(
			"//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold']"))
			.getText();
	String totalPriceWith$ = driver.findElement(By.xpath(
			"//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']"))
			.getText();

	@Given("Launch the Amazon URL")
	public void launch_the_amazon_url() {
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		throw new io.cucumber.java.PendingException();
	}

	@When("Enter productname as {string}")
	public void searchProduct(String productname) {
		driver.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("hats for men");

	}

	@When("Click on search button")
	public void clickSearchButton() {
		driver.findElement(By.id("nav-search-submit-button")).click();
	}

	@When("Click on first hat in the product list")
	public void getFirstProduct() {
		driver.findElement(By.xpath(
				"//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//img[1]"))
				.click();

	}

	@When("Select hat quantity as two from dropdown")
	public void selectProductQntyOne() {
		driver.findElement(By.xpath("//span[@class='a-dropdown-label']")).click();
		driver.findElement(By.xpath("//a[@id='quantity_1']")).click();
	}

	@When("Click on Add to cart button")
	public void addToCartButton() {
		driver.findElement(By.id("add-to-cart-button")).click();
	}

	@Then("Verify success message")
	public void productAddedMessage() {
		String successMessage = driver
				.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base sw-atc-text a-text-bold']"))
				.getText();
		System.out.println(successMessage);
	}

	@When("Click on Cart button or on Go to Cart button")
	public void goToCartButton() {
		driver.findElement(By.id("nav-cart-text-container")).click();
	}

	@Then("Verify correct product quantity is displayed")
	public void productQuanityAsTwo() {
		String[] productQnty = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).getText()
				.split(":");
		Assert.assertEquals(productQnty[1], "2");
		System.out.println("Assert successful, hat quantity updated as :" + productQnty[1]);
	}

	/*
	 * @And("Get the price for one quantity") public void getProductPrice() throws
	 * InterruptedException { Thread.sleep(3000);
	 * 
	 * }
	 */

	@Then("Verify correct total price is displayed")
	public void totalPriceForTwo() {
		// String singleHatPriceWith$ =
		// driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base
		// sc-price sc-white-space-nowrap sc-product-price a-text-bold']")).getText();

		p = Pattern.compile("[^0-9]*([0-9]*,?([0-9]+(\\.[0-9]*))?)");
		Matcher m = p.matcher(singleHatPriceWith$);
		m.matches();
		String singleHatPrice_str = m.group(1).replace(",", "");

		Double singleHatPrice = Double.valueOf(singleHatPrice_str);
		System.out.println("Price for one hat :" + singleHatPrice);

		// String totalPricerWith$ =
		// driver.findElement(By.xpath("//span[@id='sc-subtotal-amount-activecart']//span[@class='a-size-medium
		// a-color-base sc-price sc-white-space-nowrap']")).getText();
		Matcher m1 = p.matcher(totalPriceWith$);
		m1.matches();
		String twoHatsPrice_num = m1.group(1).replace(",", "");

		Double totalPriceForTwo = Double.valueOf(twoHatsPrice_num);

		Assert.assertEquals(totalPriceForTwo, singleHatPrice * 2);
		System.out.println("Assert success, price for two hats correctly updated as :" + totalPriceForTwo);
	}

	@When("Change the hat quanitity as one from the dropdown")
	public void selectProductQntyTwo() {
		driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).click();
		driver.findElement(By.id("quantity_1")).click();
	}

	@Then("Verify hat quantity is updated as one")
	public void productQuanityAsOne() {
		String[] productQntyOne = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).getText()
				.split(":");
		Assert.assertEquals(productQntyOne[1], "1");
		System.out.println("Assert successful, hat quantity updated :" + productQntyOne[1]);
	}

	@And("Verify total price is updated correctly for one hat")
	public void totalPriceForOne() {
		String singleHat = driver.findElement(By.xpath(
				"//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap sc-product-price a-text-bold']"))
				.getText();
		System.out.println(singleHat);
		String totalPriceUpdated = driver.findElement(By.id("sc-subtotal-amount-activecart")).getText();
		System.out.println(totalPriceUpdated);
		Assert.assertEquals(totalPriceUpdated, singleHat);

	}

}